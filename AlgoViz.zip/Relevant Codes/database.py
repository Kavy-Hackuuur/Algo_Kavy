import sqlite3
from email_utils import send_confirmation_email

DB_FILE = "D:\\Clg projects\\Proj-6thsem\\Project_new_vs\\Proj_vs_distributed\\Relevant Codes\\users.db"

def setup_database():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
    """)
    conn.commit()
    conn.close()

def register_user(email, username, password):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (email, username, password) VALUES (?, ?, ?)", (email, username, password))
        conn.commit()
        send_confirmation_email(email)
        conn.close()
        return True, "User registered successfully! Please log in."
    except sqlite3.IntegrityError as e:
        return False, "Username or Email already exists!"

def authenticate_user(identifier, password):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE (email = ? OR username = ?) AND password = ?", (identifier, identifier, password))
    user = cursor.fetchone()
    conn.close()
    return user

setup_database()
