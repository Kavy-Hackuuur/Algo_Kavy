import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_confirmation_email(email):
    sender_email = "dkdronkavan@gmail.com"  # Replace with your email
    sender_password = "kwschqtjxfuapqut"  # Replace with your email password
    subject = "Successfully registered to VizLogic - An Algorithm Visualizer app"
    body = "Congratulations! You have successfully registered. Enjoy using the app!"

    try:
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(msg)
        server.quit()
        return True, "Email sent successfully."
    except Exception as e:
        return False, f"Failed to send email: {e}"
